/**
 * 
 */
package com.cg.neel.igrs.payment.jwtConfiguration;

/**
 * 
 */
public class IgrsUser{

	private String userId;
	private String username ;
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	


	
	
}
