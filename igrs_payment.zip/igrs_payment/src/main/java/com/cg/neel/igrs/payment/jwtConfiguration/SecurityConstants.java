/**
 * 
 */
package com.cg.neel.igrs.payment.jwtConfiguration;

/**
 * @author Preeti
 *
 */
public interface SecurityConstants {

	public static final String JWT_KEY = "jH+/ZP0OpbZXQpgQZMuZ1u4mYr5SXGyjDvq8Tk/zOcM=";
	public static final String JWT_HEADER = "Authorization";
}
