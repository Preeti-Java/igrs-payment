/**
 * 
 */
package com.cg.neel.igrs.payment.bean;

import com.cg.neel.igrs.payment.utils.DateAudit;

/**
 * 
 */

public class PaymentRefundAccessBean extends DateAudit{

}
