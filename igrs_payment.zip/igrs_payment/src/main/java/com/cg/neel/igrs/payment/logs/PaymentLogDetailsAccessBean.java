/**
 * 
 */
package com.cg.neel.igrs.payment.logs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author Preeti
 *
 */

@Entity
@Table(name= "PAYMENTLOGDETAILS")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PaymentLogDetailsAccessBean {
	
	@Id
	@Column(name = "PAYMENTLOGDETAILS_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long paymentLogDetailsId;
	
	@ManyToOne
	@JoinColumn(name = "paymentLogId")
	private PaymentLogAccessBean paymentLogAccessBean;
	
	
	@ManyToOne
	@JoinColumn(name = "paymentEventParameterId")
	private PaymentEventParameterAccessBean paymentEventParameterAccessBean;
	
	@Column(name = "VALUE")
	private String value;
	
	

}
